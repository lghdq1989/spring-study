package com.boottest.service;

/**
 * @Author: wangk
 * @Date: 2018/12/17 15:48
 */
public interface TestService {

    String demo();

}
